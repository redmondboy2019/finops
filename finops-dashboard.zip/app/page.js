"use client";
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const spendData = [
  { name: "Retail", value: 800 },
  { name: "Markets", value: 600 },
  { name: "Risk", value: 300 },
  { name: "Ops", value: 200 }
];

const trendData = [
  { month: "Jan", spend: 200 },
  { month: "Feb", spend: 300 },
  { month: "Mar", spend: 400 },
  { month: "Apr", spend: 350 }
];

export default function Dashboard() {
  return (
    <div style={{padding:20, background:"#f1f5f9", minHeight:"100vh"}}>
      <h1 style={{fontSize:24, fontWeight:"bold", marginBottom:20}}>FinOps Banking Dashboard</h1>

      <div style={{display:"grid", gridTemplateColumns:"repeat(4, 1fr)", gap:10}}>
        <Card><CardContent>Total Spend: $2B+</CardContent></Card>
        <Card><CardContent>Accounts: 1200+</CardContent></Card>
        <Card><CardContent>Unallocated: 60%</CardContent></Card>
        <Card><CardContent>Savings: $120M</CardContent></Card>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginTop:20}}>
        <Card>
          <CardContent>
            <h2>Spend by Business Unit</h2>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={spendData} dataKey="value" nameKey="name" outerRadius={100}>
                  {spendData.map((entry, index) => (
                    <Cell key={index} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <h2>Monthly Spend Trend</h2>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={trendData}>
                <XAxis dataKey="month" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="spend" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:20, marginTop:20}}>
        <Card>
          <CardContent>
            <h2>Data Ingestion Sources</h2>
            <ul>
              <li>AWS CUR</li>
              <li>Azure Cost Export</li>
              <li>GCP Billing</li>
              <li>CMDB Metadata</li>
              <li>Business Cost Centers</li>
            </ul>
          </CardContent>
        </Card>

        <Card>
          <CardContent>
            <h2>FinOps Pillars</h2>
            <ul>
              <li>Visibility</li>
              <li>Accountability</li>
              <li>Governance</li>
              <li>Optimization</li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
