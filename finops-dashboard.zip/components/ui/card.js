export function Card({ children }) {
  return (
    <div style={{background:"#fff", borderRadius:12, padding:10, boxShadow:"0 2px 6px rgba(0,0,0,0.1)"}}>
      {children}
    </div>
  );
}

export function CardContent({ children }) {
  return <div>{children}</div>;
}
